package co.com.AutomatizacionFormy.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;

@DefaultUrl(value = "https://formy-project.herokuapp.com/form")

public class FormularioPage extends PageObject {

        public static final Target FIRST_NAME = Target.the("Campo de nombre")
                .located(By.id("first-name"));

        public static final Target LAST_NAME = Target.the("Campo de apellido")
                .located(By.id("last-name"));


        public static final Target JOB_TITLE = Target.the("Campo de título profesional")
                .located(By.id("job-title"));
        public static final Target RADIO_BUTTON = Target.the("Botón de radio")
                .located(By.id("radio-button-2"));

        public static final Target CHECKBOX = Target.the("Checkbox")
                .located(By.id("checkbox-1"));

        public static final Target AÑOS_EXPERIENCIA = Target.the("select de experiencia").located(By.id("select-menu"));
        public static final Target FECHA_NACIMIENTO = Target.the("campo de fecha").located(By.id("datepicker"));


        public static final Target SUBMIT = Target.the("Botón de enviar")
                .located(By.cssSelector(".btn.btn-lg.btn-primary"));


}
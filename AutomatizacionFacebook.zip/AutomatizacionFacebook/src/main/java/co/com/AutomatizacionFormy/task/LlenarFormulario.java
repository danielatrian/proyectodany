package co.com.AutomatizacionFormy.task;

import co.com.AutomatizacionFormy.userinterface.FormularioPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.*;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static net.serenitybdd.screenplay.actions.Enter.theValue;
import static net.serenitybdd.screenplay.actions.Click.on;


public class LlenarFormulario implements Task {

    public static LlenarFormulario condatosEjemplo() {
        return instrumented(LlenarFormulario.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue("Danny").into(FormularioPage.FIRST_NAME),
                Enter.theValue("Triana").into(FormularioPage.LAST_NAME),
                Enter.theValue("Ingeniera de sistemas").into(FormularioPage.JOB_TITLE),
                Click.on(FormularioPage.RADIO_BUTTON),
                Click.on(FormularioPage.CHECKBOX),
                Enter.theValue("05/25/1995").into(FormularioPage.FECHA_NACIMIENTO), // FECHA
                SelectFromOptions.byVisibleText("2-4").from(FormularioPage.AÑOS_EXPERIENCIA), // EXPERIENCIA
                Click.on(FormularioPage.SUBMIT)

        );
    }
}

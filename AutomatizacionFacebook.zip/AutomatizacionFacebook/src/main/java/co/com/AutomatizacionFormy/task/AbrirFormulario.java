package co.com.AutomatizacionFormy.task;

import co.com.AutomatizacionFormy.userinterface.FormularioPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Open;

public class AbrirFormulario implements Task {

    FormularioPage formularioPage;

    public static AbrirFormulario laPagina() {
        return Tasks.instrumented(AbrirFormulario.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.wasAbleTo(Open.browserOn(formularioPage));
    }
}

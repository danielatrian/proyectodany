package co.com.AutomatizacionFormy.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl(value = "https://www.facebook.com/")

public class InicioFacebook extends PageObject {
}

package co.com.AutomatizacionFormy.stepsdefinitions;

import co.com.AutomatizacionFormy.task.AbrirFormulario;
import cucumber.api.java.Before;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import co.com.AutomatizacionFormy.task.LlenarFormulario;


public class FormularioStepDefinitions {
    @Before
    public void prepararEscenario() {
        OnStage.setTheStage(new OnlineCast());
    }

    @Dado("que el usuario abre la página de Formy")
    public void queElUsuarioAbreLaPaginaDeFormy() {
        OnStage.theActorCalled("Danny").wasAbleTo(AbrirFormulario.laPagina());
    }

    @Cuando("completa todos los campos del formulario")
    public void completaTodosLosCamposDelFormulario() {
        OnStage.theActorInTheSpotlight().attemptsTo(co.com.AutomatizacionFormy.task.LlenarFormulario.condatosEjemplo());
    }

    @Entonces("debería ver un mensaje de confirmación")
    public void deberiaVerUnMensajeDeConfirmacion() {
        //  validar la navegación o un texto visible
    }
}
